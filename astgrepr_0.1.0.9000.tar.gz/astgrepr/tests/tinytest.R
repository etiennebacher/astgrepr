if (requireNamespace("tinytest", quietly = TRUE)) {
  tinytest::test_package("astgrepr", testdir = "tinytest")
}
